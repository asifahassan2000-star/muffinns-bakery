const Network_Recorder = {
    _track_type: ['fetch', 'xmlhttp'],

    observer: null,
    data: [],
    originalOpen: null,
    originalSend: null,
    originalSendRequestHeader: null,
    initTime: 0,
    listeners: [],
    bufferLength: 1000,

    init: function() {
        this.initTime = Date.now();

        try {
            this.observer = new PerformanceObserver((list) => {
                list.getEntries().forEach((entry) => {
                    const request = entry.toJSON();
                    request.id = this.uid();
                    request.timestamp = Date.now();

                    this.track(request);
                });
            });

            this.observer.observe({ type: "resource", buffered: true });
            this.observer.observe({ type: "navigation", buffered: true });
        } catch (e) {
            // no need to handle this, unless it impacts the behavior of the fetch/xhr patches below.
        }

        if (false) {
            // TODO: If we decide we want additional logging for fetch/xmlhttprequest, particularly request methods, headers, body, etc,
            // then these should be enabled/implemented fully, noting that the Performance API tracks the requests in duplicate also.

            try {
                if (typeof window._stdFetch === 'undefined') {
                    window._stdFetch = window.fetch;
                }

                const XHR = {
                    open: window.XMLHttpRequest.prototype.open,
                    send: window.XMLHttpRequest.prototype.send,
                    setRequestHeader: window.XMLHttpRequest.prototype.setRequestHeader
                };

                window.XMLHttpRequest._std = XHR;

                window.fetch = async function (resource, options) {
                    const ubRequest = {
                        initiatorType: 'fetch',
                        id: this.uid(),
                        requestStart: (Date.now() - this.initTime) / 1000,
                        timestamp: Date.now()
                    };

                    // TODO: header, body?
                    if (typeof resource === 'object') {
                        ubRequest.name = resource.url ?? '';
                        ubRequest.method = resource.method ?? '';
                    } else if (typeof resource === 'string') {
                        ubRequest.name = resource;

                        if (typeof options === 'object') {
                            ubRequest.method = options.method ?? 'GET';
                        }
                    };

                    // console.log('fetch', ubRequest, arguments);
                    const fetchPromise = window._stdFetch.apply(this, arguments);
                    this.track(ubRequest, fetchPromise);
                    return fetchPromise;
                };

                window.XMLHttpRequest.prototype.open = function (method, url, async) {
                    this.ubRequest = {
                        initiatorType: 'XMLHttpRequest',
                        id: this.uid(),
                        method: method,
                        headers: {},
                        timestamp: Date.now()
                    };
                    if (typeof url === 'string') {
                        this.ubRequest.name = url;
                    } else {
                        this.ubRequest.name = url.toString();
                    }

                    return XHR.open.apply(this, arguments);
                };

                window.XMLHttpRequest.prototype.send = function (body) {
                    this.ubRequest.body = body;
                    this.ubRequest.requestStart = (Date.now() - this.initTime) / 1000;

                    console.log('XHR Send', this.ubRequest, JSON.stringify(arguments));

                    this.addEventListener('load', async function(event) {
                        this.ubRequest.responseEnd = (Date.now() - this.initTime) / 1000;
                        this.ubRequest.responseStatus = this.status;

                        // console.log('Load Event: '+ event.loaded, this.ubRequest);
                        this.track(this.ubRequest);
                    });

                    this.addEventListener('error', async function(event) {
                        this.ubRequest.responseEnd = (Date.now() - this.initTime) / 1000;
                        this.ubRequest.responseStatus = this.status;

                        // console.log('Error Event', JSON.stringify(event));
                        this.track(this.ubRequest);
                    });

                    return XHR.send.apply(this, arguments);
                };

                // depends on our appetite for recording request headers
                window.XMLHttpRequest.prototype.setRequestHeader = function (header, value) {
                    this.ubRequest.headers[header] = value;

                    return XHR.setRequestHeader.apply(this, arguments);
                };

            } catch (e) {
                // TODO - best way to handle this? maybe remove the try block?
                //console.log(e);
            }
        }
    },

    isRecording: function() {
        return !!this.observer;
    },

    stop: function() {
        this.observer?.disconnect();
        this.observer = null;
        this.clear();
        return;

        // TODO: Only required if we patch fetch/xmlhttpreqeust
        if (typeof window.fetch._std !== undefined) {
            window.fetch = window.fetch._std;

            window.XMLHttpRequest.prototype.open = window.XMLHttpRequest._std.open;
            window.XMLHttpRequest.prototype.send = window.XMLHttpRequest._std.send;
            window.XMLHttpRequest.prototype.setRequestHeader = window.XMLHttpRequest._std.setRequestHeader;

            delete window.XMLHttpRequest._std;
        }
    },

    listen: function(fn) {
        const idx = this.listeners.push(fn) - 1;

        // push any buffered data immediately
        this.data.forEach((data) => {
            fn(data);
        });

        return idx;
    },

    track: async function(data, promise) {
        const validated_data = this.validate(data);

        if (promise ?? false) {
            // Used by fetch only
            Promise.resolve(promise).then((response) => {
                validated_data.responseStatus = response.status;
                validated_data.responseEnd = (Date.now() - this.initTime) / 1000;
                validated_data.encodedBodySize = response.headers.get('Content-Length');
            }, (error) => {
                // TODO: may need to be handled if fetch is patched
            });
        }

        if (this.listeners.length > 0) {
            this.listeners.forEach((fn) => {
                fn(validated_data);
            });
        }

        // Buffer up to bufferLength, and automatically send everything to new listeners or when calling getData
        this.data.push(validated_data);

        if (this.data.length > this.bufferLength) {
            this.data.shift();
        }
    },

    getAll: function() {
        return this.data;
    },

    clear: function() {
        const data = this.data;
        this.data = [];
        return data;
    },

    validate: function(data) {
        // Soft validation: always return a normalized log object with safe defaults.
        const log = (data && typeof data === 'object') ? {...data} : {};

        if (typeof log.id !== 'string' || !log.id.length) {
            log.id = this.uid();
        }

        if (typeof log.timestamp !== 'number' || !isFinite(log.timestamp)) {
            log.timestamp = 0;
        }

        if (typeof log.responseStatus !== 'number' || !isFinite(log.responseStatus)) {
            log.responseStatus = 0;
        }

        if (typeof log.name !== 'string') {
            if (log.name === undefined || log.name === null) {
                log.name = '';
            } else {
                log.name = String(log.name);
            }
        }

        // Keep URL-ish fields bounded to avoid oversized payloads.
        if (log.name.length > 2000) {
            log.name = log.name.substring(0, 2000);
        }

        if (typeof log.requestStart !== 'number' || !isFinite(log.requestStart)) {
            log.requestStart = 0;
        }

        if (typeof log.responseEnd !== 'number' || !isFinite(log.responseEnd)) {
            log.responseEnd = 0;
        }

        if (Array.isArray(log.serverTiming) && log.serverTiming.length > 50) {
            log.serverTiming = log.serverTiming.slice(0, 50);
        }

        return log;
    },

    uid: function() {
        if (typeof window.crypto !== 'undefined' && typeof window.crypto.randomUUID === 'function') {
            return window.crypto.randomUUID();
        } else {
            return Math.random().toString(36).substring(2) +
                   Math.random().toString(36).substring(2) +
                   Math.random().toString(36).substring(2);
        }
    }
};

export default Network_Recorder;