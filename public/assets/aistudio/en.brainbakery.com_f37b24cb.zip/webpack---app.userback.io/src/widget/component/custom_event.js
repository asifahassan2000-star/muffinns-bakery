import Config from '../config';
import { event_bus } from 'lib/event_bus';
import lib from 'lib/lib';

const interval = 5 * 1000; // 5 sec
const trigger_event_queue_max = 100; // max limit for the trigger_event_queue
const event_data_queue_max = 100; // max limit for the event_data_queue
const existing_events_max = 1000; // max limit for the existing_events

const meta_operators = [
    'is',
    'is_not',
    'contains',
    'contains_not',
    'starts',
    'ends',
    'greater',
    'less'
];

const Custom_Event = {
    trigger_event_queue: [], // this will log events to decide when to trigger the event, there will be max limit, and FIFO
    event_data_queue: [], // this will hold the event data to be processed, when the data is processed, it will be removed from the queue
    existing_events: new Map(), // This will hold the existing events and their metadata keys, this will be used to check if the event or meta is new or not.
    timer: null,
    access_token: null,
    init: function(access_token) {
        this.access_token = access_token;
        // load trigger_event_queue from the session storage
        this.trigger_event_queue = JSON.parse(lib.sessionStorage.get('trigger_event_queue_' + this.access_token) || '[]');
        // load existing events from the local storage
        this.existing_events = new Map(JSON.parse(lib.storage.get('existing_events_' + this.access_token) || '[]'));
    },
    processEventQueue: async function() {
        if (this.event_data_queue.length === 0) {
            return;
        }

        // Process the event_data_queue
        var form_data = new FormData();
        form_data.append('action',       'js_snippet/logEvent');
        form_data.append('access_token', Config.access_token);
        form_data.append('data',   JSON.stringify(this.event_data_queue));

        const response = await fetch(Config.request_url + '/?logEvent', {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            body: form_data
        });
        const data = await response.json();

        if (data) {
            // clean up the event_data_queue
            this.event_data_queue = [];
            return data;
        } else {
            console.warn('Failed to log event:', data.message);
            return false;
        }
    },
    isEventExisted: function(event_title) {
        // Check if the event_title exists in the existing_events
        return this.existing_events.has(event_title);
    },

    pushTriggerEventQueue: function(event_title, event_data) {
        // fifo
        // trigger_event_queue will have a max limit, and the oldest event will be removed
        this.trigger_event_queue.push({
            event_name: event_title,
            event_data: event_data
        });

        if (this.trigger_event_queue.length > trigger_event_queue_max) {
            this.trigger_event_queue.shift(); // remove the oldest event
        }

        // save the trigger_event_queue to the session storage
        lib.sessionStorage.set('trigger_event_queue_' + this.access_token, JSON.stringify(this.trigger_event_queue));
    },

    pushEventDataQueue: function(event_title, event_data) {
        // fifo, the event_data_queue will have a max limit, and the oldest event will be removed
        this.event_data_queue.push({
            event_name: event_title,
            event_data: event_data
        });

        if (this.event_data_queue.length > event_data_queue_max) {
            this.event_data_queue.shift(); // remove the oldest event
        }
    },

    updateExistingEventQueue: function(event_title, event_data_keys) {
        // fifo, the event_data_queue will have a max limit, and the oldest event will be removed
        if (!this.existing_events.has(event_title)) {
            this.existing_events.set(event_title, event_data_keys);
        } else {
            // If the event_title already exists, merge the new data with the existing data
            const existing_event_data = this.existing_events.get(event_title) || [];
            this.existing_events.set(event_title, [
                ...new Set([
                    ...existing_event_data,
                    ...event_data_keys
                ])
            ]);
        }

        // check max of existing_events, if it exceeds the limit, remove the oldest event
        if (this.existing_events.size > existing_events_max) {
            // remove the oldest event
            const first_key = this.existing_events.keys().next().value;
            this.existing_events.delete(first_key);
        }

        // save the existing_events to the local storage
        lib.storage.set('existing_events_' + this.access_token, JSON.stringify(Array.from(this.existing_events.entries())));
    },

    updateEvent: function(event_title, event_data) {
        this.pushTriggerEventQueue(event_title, event_data);

        // Check if the event_title already exists in the existing_events
        if (!this.isEventExisted(event_title)) {
            // update event data queue with the new data
            this.pushEventDataQueue(event_title, event_data);
            this.updateExistingEventQueue(event_title, [...new Set(Object.keys(event_data))]);
        } else {
            // If the event already exists, merge the new data with the existing data
            const existing_event_data = this.existing_events.get(event_title) || [];

            // Update the event_data_queue with the new data only if there are new keys in event_data
            const new_keys = Object.keys(event_data).filter(key => !existing_event_data.includes(key));
            if (new_keys.length > 0) {
                this.pushEventDataQueue(event_title, event_data);
            }

            this.updateExistingEventQueue(event_title, [
                ...new Set([
                    ...existing_event_data,
                    ...Object.keys(event_data)
                ])
            ]);
        }
    },
    log: function(event_title, event_data) {
        // validate event_data
        if (!event_title) {
            console.warn('Event name is required.');
            return false;
        }

        if (event_title.length > 100) {
            console.warn('Event name must be less than 100 characters.');
            return false;
        }
        var data_copy = {...event_data};
        Object.keys(data_copy).forEach((key) => {
            if (!this.validate(data_copy[key])) {
                delete data_copy[key];
                console.warn('Invalid "' + key + '". meta value must be String, Number or Boolean');
            }
        });

        this.updateEvent(event_title, data_copy);
        event_bus.dispatchEvent(new CustomEvent('userback::custom_event_added', {
            event_title: event_title,
            event_details: data_copy
        }));


        // start the timer if it is not already running
        if (!this.timer) {
            this.timer = setTimeout(() => {
                this.processEventQueue();

                // clear the timer
                this.timer = null;
            }, interval);
        }
    },

    // validate event info
    validate: function(value) {
        if (typeof value !== 'number' && typeof value !== 'string' && typeof value !== 'boolean') {
            return false;
        }

        return true;
    },
    // this will check if the event_condition is matched by givien event_condition
    checkEventCondition: function(event_condition) {
        // Check if event_condition is object
        if (!event_condition || typeof event_condition !== 'object') {
            return false;
        }

        if (event_condition.operator === 'or') {
            // Check if any of the event conditions match
            // Get the last events from Custom_Event.trigger_event_queue
            let last_events = [];
            if (this.trigger_event_queue.length > 0) {
                // Get the last 1 event
                last_events = this.trigger_event_queue.slice(-1);
            }

            return isConditionAnyMatched(event_condition.conditions, last_events);
        } else {
            // Check if all of the events should match with Custom_Event.trigger_event_queue's last events
            return isConditionAllMatched(event_condition.conditions, this.trigger_event_queue);
        }
    }
}

export default Custom_Event;

function isConditionAnyMatched(conditions, event_queue) {
    if (!Array.isArray(conditions) || !Array.isArray(event_queue)) return false;

    for (let i = 0; i < conditions.length; i++) {
        const condition = conditions[i];

        // loop through event queue
        for (let j = 0; j < event_queue.length; j++) {
            const event = event_queue[j];

            if (!event || !event.event_name || !condition || !condition.event_name) {
                continue; // Skip to next condition if event or condition is not defined
            }

            if (condition.event_name !== event.event_name) {
                continue; // Skip to next condition if key_name does not match
            }

            const event_data = event.event_data || {};

            if (checkMetaCondition(condition, event_data)) {
                return true; // If condition is matched, return true
            }
        }
    }

    return false; // No conditions matched
}

function isConditionAllMatched(conditions, event_queue) {
    if (!Array.isArray(conditions) || !Array.isArray(event_queue)) return false;
    if (event_queue.length < conditions.length) return false;

    const recent_events = [...event_queue];
    let current_index = recent_events.length - 1;

    // Last condition MUST match the last event
    const last_condition = conditions[conditions.length - 1];
    const last_event = recent_events[current_index];

    if (!last_event || !last_condition || !last_event.event_name || !last_condition.event_name) {
        return false; // If last event or last condition is not defined, return false
    }

    if (
        last_condition.event_name !== last_event.event_name ||
        !checkMetaCondition(last_condition, last_event.event_data || {})
    ) {
        return false;
    }

    current_index--; // Move to the previous event for next condition

    // Check remaining conditions in reverse (from 2nd last up to 1st)
    for (let cond_index = conditions.length - 2; cond_index >= 0; cond_index--) {
        const condition = conditions[cond_index];
        let matched = false;

        for (let i = current_index; i >= 0; i--) {
            const event = recent_events[i];

            if (
                condition.event_name === event.event_name &&
                checkMetaCondition(condition, event.event_data || {})
            ) {
                current_index = i - 1;
                matched = true;
                break;
            }
        }

        if (!matched) {
            return false;
        }
    }

    return true;
}

function checkMetaCondition(condition, event_data) {
    if (!condition || !event_data) {
        return false;
    }

    if (!condition.meta_key || !condition.operator || !condition.value) {
        return true;
    }

    if (!meta_operators.includes(condition.operator)) {
        return false;
    }

    // Check if the meta_key exists in event_data
    const value = event_data[condition.meta_key];

    if (value === undefined) {
        return false; // If meta_key does not exist, return false
    }

    // Handle operator logic
    switch (condition.operator) {
        case 'is':
            return value == condition.value; // Check if value is equal to condition value
        case 'is_not':
            return value !== condition.value; // Check if value is not equal to condition value
        case 'contains':
            return typeof value === 'string' && value.includes(condition.value); // Check if value contains condition value
        case 'contains_not':
            return typeof value === 'string' && !value.includes(condition.value); // Check if value does not contain condition value
        case 'starts':
            return typeof value === 'string' && value.startsWith(condition.value); // Check if value starts with condition value
        case 'ends':
            return typeof value === 'string' && value.endsWith(condition.value); // Check if value ends with condition value
        case 'greater':
            // convert condition.value to number if it is a number
            let condition_value = condition.value;
            if (typeof condition_value === 'string' && !isNaN(condition_value)) {
                condition_value = parseFloat(condition.value);
            }

            let posted_value = value;
            if (typeof posted_value === 'string' && !isNaN(posted_value)) {
                posted_value = parseFloat(posted_value); // Convert string to number if it is a number
            }
            return posted_value > condition_value; // Check if value is greater than condition value
        case 'less':
            // convert condition.value to number if it is a number
            condition_value = condition.value;
            if (typeof condition_value === 'string' && !isNaN(condition_value)) {
                condition_value = parseFloat(condition.value);
            }
            if (typeof posted_value === 'string' && !isNaN(posted_value)) {
                posted_value = parseFloat(posted_value); // Convert string to number if it is a number
            }
            return posted_value < condition_value; // Check if value is less than condition value
        default:
            return false; // If operator is not recognized, return false
    }
}