import Config from '../config';
import createSurveyComponent from './survey_component';
import User_Identification from 'component/user_identification';
import Session_Recorder from 'component/session_recorder';
import rage from 'component/rage';
import Lib from 'lib/lib';
import {event_bus} from 'lib/event_bus';
import Custom_Event from 'component/custom_event';

import {
    addGlobalEventListener,
    isGlobalEventListenerAdded,
    removeGlobalEventListener
} from './global_event';

import {
    isValidateCondition,
    isValidateScreenCondition,
    isValidateDevice,
    isValidateFrequency,
    isValidatePosition,
    isValidateSurveySize,
    isValidateTriggerType,
    isValidateTriggerDelay,
    isValidateTriggerAction,
    isValidateUserSegment,
    isValidateFormat,
    isValidateBackgroundColour,
    isValidateUiTheme
} from './validate';

import {isDesktop, isMobile, isTablet} from './device';
import {isUsed as isUsedFingerPrint, record as recordFingerPrint} from './finger_print';
import {isValidQuerySelector} from './util';
import styles from './main.module.scss';
import {postNativeMessage} from 'lib/native_bridge';

let local_configs = [];
let local_open_survey = [];
let local_initial_url = window.location.href;
let local_session_data = null;
let local_custom_data = null;
let local_is_demo_mode = false;
let local_delay_timeout = null;
let local_close_timeout = null;
let local_rage_timeout = null;
let local_rage = null;
let local_custom_event_timeout = null;
let local_api_call = {};

// init survey module
export function init(survey_config) {
    if (typeof window.__USERBACK_SURVEY_EVENTS === 'undefined') {
        window.__USERBACK_SURVEY_EVENTS = {};
    }

    // check if survey is already initialized in the page
    // TODO: this does not seem to be correct
    if (!window.Userback.init) {
        return;
    }

    // check if survey config is available
    if (!survey_config || !Array.isArray(survey_config) || survey_config.length === 0) {
        return;
    }

    // Clean up timer
    if (local_delay_timeout) {
        clearTimeout(local_delay_timeout);
    }

    if (local_close_timeout) {
        clearTimeout(local_close_timeout);
    }

    if (local_rage_timeout) {
        clearTimeout(local_rage_timeout);
    }

    if (local_custom_event_timeout) {
        clearTimeout(local_custom_event_timeout);
    }

    if (window.Userback.demo_mode) {
        local_is_demo_mode = true;
    }

    // set session data
    local_session_data = window.Userback.session_data;
    local_custom_data = window.Userback.custom_data;
    local_initial_url = window.location.href;
    local_rage = rage();

    loadConfig(survey_config);

    postNativeMessage({
        type: 'survey_configs',
        payload: local_configs.map(({ key, format, position, size, has_background_colour }) => ({ key, format, position, size, has_background_colour })),
    });

    trigger(true);

    if (!isGlobalEventListenerAdded('popstate', handlePopState)) {
        addGlobalEventListener('popstate', handlePopState);
    }

    if (!isGlobalEventListenerAdded('message', handleMessageListener)) {
        addGlobalEventListener('message', handleMessageListener);
    }

    if (!isGlobalEventListenerAdded('click', handleElementClick)) {
        // Add global click event
        addGlobalEventListener('click', handleElementClick, true);
    }

    local_rage.on(handleRageClick);
    event_bus.addEventListener('userback::custom_event_added', handleCustomEventAdded);
    event_bus.addEventListener('userback::screen_view', handleScreenView);

    setAPIHooks();
}

// open survey
export function trigger(is_page_load = false) {
    if (local_is_demo_mode) {
        if (local_configs.length > 0) {
            open(local_configs[0]);
        }

        return;
    }

    // loop through each survey config
    const filtered_configs = getConfigsAfterConditionCheck();

    // only allow time trigger when page is loaded
    const survey_to_trigger = getMatchedSurvey(filtered_configs.filter((config) => {
        return config.trigger_type === 'time';
    }));

    if (!survey_to_trigger) {
        return;
    }

    const {trigger_delay} = survey_to_trigger;

    if (is_page_load) {
        local_delay_timeout = setTimeout(() => {
            open(survey_to_trigger);
        }, trigger_delay * 1000);
    } else {
        open(survey_to_trigger);
    }
}

function setAPIHooks() {
    if (validateAPIHook('on_survey_submit', Userback)) {
        local_api_call.on_survey_submit = Userback.on_survey_submit;
    }
}

export function removeAPIHooks() {
    local_api_call = {};

    delete window.Userback['on_survey_submit'];
}

function validateAPIHook(hook_name, obj) {
    switch (hook_name) {
        case 'on_survey_submit':
            return typeof obj[hook_name] === 'function';
    }
}

function getConfigsAfterConditionCheck() {
    return local_configs.filter((config) => {
        // check survey match device conditions (skip for mobile SDK)
        if (!Config.isMobileSDK() && !checkDevice(config)) {
            return false;
        }

        // check survey match frequency conditions
        if (!checkFrequency(config)) {
            return false;
        }

        if (Config.isMobileSDK()) {
            // check survey match screen conditions (mobile SDK)
            if (!checkScreens(config)) {
                return false;
            }
        } else {
            // check survey match page conditions (web)
            if (!checkPages(config)) {
                return false;
            }
        }

        // check user segment conditions
        if (!checkUserSegment(config)) {
            return false;
        }

        if (config.trigger_type === 'event' && !Custom_Event.checkEventCondition(config.event_condition)) {
            return false;
        }

        return true;
    });
}

function handleRageClick() {
    if (!local_rage) {
        return;
    }

    // clear timeout if rage click is triggered
    if (local_rage_timeout) {
        // clear timeout for rage click
        clearTimeout(local_rage_timeout);
    }

    let filtered_configs = getConfigsAfterConditionCheck();

    // filter the configs which trigger type is rage, and there is an action
    filtered_configs = filtered_configs.filter((config) => {
        return config.trigger_type === 'rage';
    });

    // check if the rage click is matched with the queryselector result of trigger action
    const survey_to_trigger = getMatchedSurvey(filtered_configs);
    if (survey_to_trigger) {
        const {trigger_delay} = survey_to_trigger;
        // set timeout to open survey
        local_rage_timeout = setTimeout(() => {
            open(survey_to_trigger);
        }, trigger_delay * 1000);
    }
}

function handleElementClick(e) {
    const target = e.target;

    let filtered_configs = getConfigsAfterConditionCheck().filter(
        (config) => config.trigger_type === "element" && config.trigger_action
    );

    filtered_configs.forEach((config) => {
        const { trigger_action } = config;
        if (!isValidQuerySelector(trigger_action)) return;

        let matched = false;

        if (target.matches(trigger_action)) {
            matched = true;
        } else {
            const path = e.composedPath ? e.composedPath() : [target];
            const match = path.find((el) =>
                el.matches ? el.matches(trigger_action) : false
            );
            if (match) {
                matched = true;
            }
        }

        if (matched) {
            open(config);
        }
    });
}

function handleCustomEventAdded(event) {
    if (!local_custom_event_timeout) {
        clearTimeout(local_custom_event_timeout);
    }

    // Check if there are any surveys that match the event conditions
    let filtered_configs = getConfigsAfterConditionCheck();

    filtered_configs = filtered_configs.filter((config) => {
        return config.trigger_type === 'event';
    });

    const survey_to_trigger = getMatchedSurvey(filtered_configs);
    if (survey_to_trigger) {
        const {trigger_delay} = survey_to_trigger;
        // set timeout to open survey
        local_custom_event_timeout = setTimeout(() => {
            open(survey_to_trigger);
        }, trigger_delay * 1000);
    }
}

// close all survey
export function closeAll() {
    // loop through each local_open_survey
    for (const open_survey of local_open_survey) {
        close(open_survey.key);
    }

    // clean up local_open_survey
    local_open_survey = [];
}

export function close(key) {
    // Search key in local_open_survey
    const survey_open_by_key = local_open_survey.filter((survey) => {
        return survey.key === key;
    });

    if (survey_open_by_key.length === 0) {
        return;
    }

    const survey_to_close = survey_open_by_key[0];
    if (survey_to_close.scroll_container && survey_to_close.handle_scroll) {
        survey_to_close.scroll_container.removeEventListener('scroll', survey_to_close.handle_scroll);
    }
    survey_to_close.dom.remove();
    if (survey_to_close.scroll_indicator) {
        survey_to_close.scroll_indicator.remove();
    }
    // remove survey from local_open_survey
    local_open_survey = local_open_survey.filter((survey) => {
        return survey.key !== key;
    });

    postNativeMessage({ type: 'survey_close', payload: { key } });

    // Create a survey close
    if (local_is_demo_mode) {
        // When in demo mode, we need to send event to notify survey close
        const close_event = new CustomEvent('userback:survey:close', {key});

        document.dispatchEvent(close_event);
    }
}

export function api() {
    return {
        init: function() {
            init();
        },

        isOpen: function(key) {
            if (key) {
                return local_open_survey.filter((survey) => {
                    return survey.key === key;
                }).length > 0;
            } else {
                return local_open_survey.length > 0;
            }
        },

        openSurvey: function(key, options) {
            // default: ignore the stop condition (existing behaviour). Callers must
            // explicitly opt out to have it respected.
            options = { skipFrequency: true, ...options };

            // Search key in configs
            const configs = local_configs.filter((config) => {
                if (config.key === key) {
                    return true;
                }
            });

            if (configs.length === 0) {
                console.warn('Survey not found');
                return;
            }

            // trigger_type '' means no in-app trigger is configured for this survey
            // (reachable via the follow-up email link instead) -- not via the JS SDK
            // either.
            if (configs[0].trigger_type === '') {
                console.warn('This survey has no in-app trigger configured and cannot be opened via the JS SDK');
            }

            if (!options.skipFrequency && !checkFrequency(configs[0])) {
                return;
            }

            open({key, ...configs[0]});
        },

        closeSurvey: function() {
            closeAll();
        },

        destroy: function() {
            closeAll();

            removeGlobalEventListener('popstate', handlePopState);
            removeGlobalEventListener('message', handleMessageListener);
            removeGlobalEventListener('click', handleElementClick);
            if (local_rage) {
                local_rage.stop();
            }

            // clear all timeouts
            if (local_delay_timeout) {
                clearTimeout(local_delay_timeout);
            }

            if (local_close_timeout) {
                clearTimeout(local_close_timeout);
            }

            if (local_rage_timeout) {
                clearTimeout(local_rage_timeout);
            }
        },

        setCustomData: function(data) {
            // make sure data is an object
            if (typeof data === 'object') {
                local_custom_data = data;
                postMessageToSurvey('survey/customData', local_custom_data, '*');
            }
        }
    }
}

// open survey
function open(config) {
    const {key} = config;

    // check whether current key is aleady open
    const survey_open_by_key = local_open_survey.filter((survey) => {
        return survey.key === key;
    });

    const is_current_key_open = survey_open_by_key.length > 0;
    if (is_current_key_open) {
        return;
    }

    // skip for mobile SDK if feedback form is open (shared WebView)
    if (Config.isMobileSDK() && document.querySelector('[isopen]')) {
        return;
    }

    // Make record of survey open
    recordFingerPrint(key, 'open');

    const { format, position, size, has_background_colour, background_colour, has_close_button, ui_theme } = config;

    const container = document.body;

    // open survey
    // create iframe on dom based on config
    const new_survey = createSurveyComponent(
        key,
        `${Config.survey_url.replace(/\/$/, '')}/${key}/e`,
        format,
        position,
        size,
        has_background_colour,
        background_colour,
        has_close_button ? handleClose: null
    );

    const iframe_uid = 'iframe-' + new Date().getTime() + '-' + Math.random().toString(36).substring(2, 11);

    let scroll_indicator = null;
    let scroll_container = null;
    let handle_scroll = null;

    if (format === 'pageless') {
        scroll_container = getPagelessScrollContainer(new_survey);

        if (scroll_container) {
            // created as a top-level sibling, not nested inside the transformed/scrolling
            // container, so its position:fixed stays anchored to the real viewport
            scroll_indicator = document.createElement('ubdiv');
            scroll_indicator.classList.add(styles['scroll-indicator']);
            scroll_indicator.classList.toggle(styles.dark, resolveTheme(ui_theme) === 'dark');
            scroll_indicator.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M201.4 374.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 306.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"/></svg>';

            scroll_indicator.addEventListener('click', () => {
                scroll_container.scrollBy({ top: scroll_container.clientHeight * 0.8, behavior: 'smooth' });
            });

            // named so it can be removed later with removeEventListener in close()
            handle_scroll = () => updateScrollIndicator(scroll_container, scroll_indicator);
            scroll_container.addEventListener('scroll', handle_scroll);
        }
    }

    local_open_survey.push({dom: new_survey, key: key, uid: iframe_uid, scroll_indicator, scroll_container, handle_scroll});

    container.appendChild(new_survey);

    if (scroll_indicator) {
        container.appendChild(scroll_indicator);
    }

    postNativeMessage({ type: 'survey_open', payload: { key } });
}

// mirrors the survey app's own getCurrentTheme() priority: explicit survey setting first,
// falling back to system preference. Needed here because this element renders outside the
// iframe, so it can't read the data-ub-colour-scheme attribute the survey sets on its own document.
function resolveTheme(ui_theme) {
    if (ui_theme === 'light' || ui_theme === 'dark') {
        return ui_theme;
    }

    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'dark';
    }

    return 'light';
}

// the scrollable pageless container is either the survey dom itself, or nested inside the overlay wrapper
function getPagelessScrollContainer(survey_dom) {
    if (survey_dom.classList.contains(styles['container-pageless'])) {
        return survey_dom;
    }

    return survey_dom.querySelector(`.${styles['container-pageless']}`);
}

// show the scroll-down indicator only while there's more pageless content below the fold
function updateScrollIndicator(scroll_container, indicator) {
    if (!indicator) {
        return;
    }

    const has_overflow = scroll_container.scrollHeight > scroll_container.clientHeight + 1;
    const near_bottom = scroll_container.scrollTop + scroll_container.clientHeight >= scroll_container.scrollHeight - 10;

    indicator.classList.toggle(styles.active, has_overflow && !near_bottom);
}

// close survey
function handleClose(key) {
    if (!local_is_demo_mode) {
        recordFingerPrint(key, 'close');
    }

    close(key);
}

// load survey config
function loadConfig(data) {
    // Set configs
    local_configs = validateSurveyConfig(data);
}

// validate survey config
function validateSurveyConfig(data) {
    if (!Array.isArray(data)) {
        return [];
    }

    const validate_data = [];

    const default_config = {
        format: 'paged',
        device: 'desktop,mobile,tablet',
        position: 'center',
        size: 'medium',
        trigger_type: 'time',
        trigger_delay: 0,
        trigger_action: '',
        user_segment: '',
        has_page_condition: false,
        has_screen_condition: false,
        has_background_colour: false,
        has_close_button: true,
        background_colour: '',
        condition: [],
        screen_condition: {},
        frequency: 'oncesubmit',
        ui_theme: 'default'
    };

    // Loop through each entry in the array and validate its properties
    for (const entry of data) {
        const new_entry = {...default_config};

        if (typeof entry === 'object') {
            if (entry.key) {
                new_entry.key = entry.key;
                new_entry.id = entry.id;

                const {
                    format,
                    device,
                    position,
                    frequency,
                    has_page_condition,
                    has_screen_condition,
                    condition,
                    screen_condition,
                    size,
                    trigger_type,
                    trigger_delay,
                    trigger_action,
                    user_segment,
                    has_background_colour,
                    has_close_button,
                    background_colour,
                    event_condition,
                    ui_theme,
                } = entry;

                if (isValidateFormat(format)) {
                    new_entry.format = format;
                }

                if (isValidateUiTheme(ui_theme)) {
                    new_entry.ui_theme = ui_theme;
                }

                if (isValidateDevice(device)) {
                    new_entry.device = device;
                }

                if (isValidatePosition(position)) {
                    new_entry.position = position;
                }

                if (isValidateSurveySize(size)) {
                    if (new_entry.position === 'top' || new_entry.position === 'bottom') {
                        new_entry.size = 'large';
                    } else {
                        new_entry.size = size;
                    }
                }

                if (isValidateFrequency(frequency)) {
                    new_entry.frequency = frequency;
                }

                if (isValidateTriggerType(trigger_type)) {
                    new_entry.trigger_type = trigger_type;
                }

                if (isValidateTriggerDelay(trigger_delay)) {
                    new_entry.trigger_delay = trigger_delay;
                }

                if (isValidateTriggerAction(trigger_action)) {
                    new_entry.trigger_action = trigger_action;
                }

                if (typeof has_page_condition !== 'boolean') {
                    new_entry.has_page_condition = !!has_page_condition;
                } else {
                    new_entry.has_page_condition = has_page_condition;
                }

                if (isValidateCondition(condition, 'page')) {
                    new_entry.condition = condition;
                }

                if (typeof has_screen_condition !== 'boolean') {
                    new_entry.has_screen_condition = !!has_screen_condition;
                } else {
                    new_entry.has_screen_condition = has_screen_condition;
                }

                if (isValidateScreenCondition(screen_condition)) {
                    new_entry.screen_condition = screen_condition;
                }

                if (isValidateCondition(event_condition, 'event')) {
                    new_entry.event_condition = event_condition;
                }

                if (isValidateUserSegment(user_segment)) {
                    new_entry.user_segment = user_segment;
                }

                if (typeof has_background_colour === 'boolean') {
                    new_entry.has_background_colour = entry.has_background_colour;
                }

                if (typeof has_close_button === 'boolean') {
                    new_entry.has_close_button = entry.has_close_button;
                }

                if (isValidateBackgroundColour(background_colour)) {
                    new_entry.background_colour = background_colour;
                }
            }
        }

        validate_data.push(new_entry);
    }

    return validate_data;
}

// check survey match device conditions
function checkDevice(config) {
    if (!config) {
        return false;
    }

    // Get device from config
    const { device } = config;

    if (!device) {
        return false;
    }

    // Get current device
    const devices = device.split(',');

    // Loop through each device and validate its value
    for (const device of devices) {
        if (device === 'desktop' && isDesktop()) {
            return true;
        }

        if (device === 'mobile' && isMobile()) {
            return true;
        }

        if (device === 'tablet' && isTablet()) {
            return true;
        }
    }

    return false;
}

// check survey match frequency conditions
function checkFrequency(config) {
    const {key} = config;

    const {frequency} = config;
    const frequency_parts = frequency.split('_');

    let recur_days = 0;
    if (frequency_parts[1] && !isNaN(frequency_parts[1])) {
        recur_days = parseInt(frequency_parts[1], 10);
    }

    const day_timestamp = 24 * 60 * 60 * 1000;

    if (frequency_parts[0] === 'once') {
        // Check second part is a number
        if (isUsedFingerPrint(key, 'once', recur_days * day_timestamp)) {
            return false;
        }
    } else if (frequency_parts[0] === 'oncesubmit') {
        if (isUsedFingerPrint(key, 'submit', recur_days * day_timestamp)) {
            return false;
        }
    } else if (frequency_parts[0] === 'close') {
        if (isUsedFingerPrint(key, 'close', recur_days * day_timestamp)) {
            return false;
        }
    }

    return true;
}

// check user segment conditions
function checkUserSegment(config) {
    const {user_segment} = config;
    if (!user_segment) {
        return true;
    }

    // feedback target only allows one segment to be used in target settings
    const segment_match = User_Identification.matchSegments(user_segment, 'or');

    return segment_match;
}

// check survey match page conditions
function checkPages(config) {
    if (!config) {
        return false;
    }

    // Pass if survey is for all pages
    if (!config.has_page_condition) {
        return true;
    }

    // Get condition from config
    const { condition } = config;

    if (!condition) {
        return false;
    }

    if (!Lib.checkUrlCondition(condition)) {
        return false;
    }

    return true;
}

// check survey match screen conditions (mobile SDK only)
function checkScreens(config) {
    if (!Config.isMobileSDK()) {
        return true;
    }

    if (!config) {
        return false;
    }

    if (!config.has_screen_condition) {
        return true;
    }

    const { screen_condition } = config;

    if (!screen_condition) {
        return false;
    }

    return Lib.checkScreenCondition(screen_condition);
}

function getMatchedSurvey(configs) {
    const matched_surveys = [];
    configs.forEach((config) => {
        let matching_weight = 0;
        if (config.user_segment) {
            matching_weight += 10;
        }

        if (Config.isMobileSDK()) {
            if (config.has_screen_condition && config.screen_condition) {
                matching_weight += 20;
            }
        } else {
            if (config.has_page_condition && config.condition) {
                matching_weight += 20;
            }
        }

        matched_surveys.push({
            config,
            matching_weight
        });
    });

    let survey_to_trigger = null;
    if (matched_surveys.length === 1) {
        survey_to_trigger = matched_surveys[0].config;
    } else if (matched_surveys.length > 1) {
        matched_surveys.sort((a, b) => {
            if (a.matching_weight === b.matching_weight) {
                return b.config.id - a.config.id;
            } else {
                return b.matching_weight - a.matching_weight;
            }
        });

        survey_to_trigger = matched_surveys[0].config;
    }

    return survey_to_trigger;
};

function postMessageToSurvey(message, data, survey_key, message_id) {
    if (survey_key === '*') {
        // look up all open surveys
        local_open_survey.forEach((survey) => {
            const iframe = survey.dom.querySelector('iframe');
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.postMessage({message, data, messageId: message_id}, '*');
            }
        });

        return;
    }
    // look up local_open_survey by survey_key
    const survey_open_by_key = local_open_survey.filter((survey) => {
        return survey.key === survey_key;
    });

    const is_current_key_open = survey_open_by_key.length > 0;

    if (is_current_key_open) {
        const iframe = survey_open_by_key[0].dom.querySelector('iframe');
        if (iframe && iframe.contentWindow) {
            iframe.contentWindow.postMessage({message, data, messageId: message_id}, '*');
        }
    }
}

function buildSessionData() {
    const native_env = Config.isMobileSDK() ? (window.Userback?.native_env || {}) : null;

    return {
        sessionId:      Session_Recorder.getSessionId(),
        identification: User_Identification.getIdentification() || '',
        userData:       JSON.stringify(User_Identification.getAll()),
        page:           native_env ? (native_env.page || local_session_data?.page || window.location.href) : (local_session_data?.page || window.location.href),
        uaData:         native_env ? JSON.stringify(window.Userback?.native_ua_data || Lib.getUAData()) : JSON.stringify(Lib.getUAData()),
        userAgent:      native_env ? (native_env.user_agent || window.navigator.userAgent) : window.navigator.userAgent,
        windowX:        native_env ? (native_env.screen_width_pt  || window.innerWidth)        : (local_session_data?.window_x     || window.innerWidth),
        windowY:        native_env ? (native_env.screen_height_pt || window.innerHeight)       : (local_session_data?.window_y     || window.innerHeight),
        resolutionX:    native_env ? (native_env.resolution_x     || window.screen.width)      : (local_session_data?.resolution_x || window.screen.width),
        resolutionY:    native_env ? (native_env.resolution_y     || window.screen.height)     : (local_session_data?.resolution_y || window.screen.height),
        dpi:            native_env ? (native_env.dpi_scale        || window.devicePixelRatio)  : (local_session_data?.dpi          || window.devicePixelRatio || 0),
        pathname:       window.location.pathname
    };
}

function handleMessageListener(event) {
    const message_data = event.data;
    const survey_key = message_data.surveyKey;

    // Get the current open survey
    const survey_open_by_key = local_open_survey.filter((survey) => {
        return survey.key === survey_key;
    });

    if (survey_open_by_key.length === 0) {
        return;
    }

    const current_open_survey = survey_open_by_key[0];
    switch(message_data.message) {
        case 'survey/init':
            postMessageToSurvey('survey/init', {uid: current_open_survey?.uid}, survey_key);
            postMessageToSurvey('survey/sessionData', buildSessionData(), survey_key);
            postMessageToSurvey('survey/customData', local_custom_data, survey_key);
            break;
        case 'survey/fetchSessionData/request':
            postMessageToSurvey('survey/fetchSessionData/response', buildSessionData(), survey_key, message_data.messageId);
            break;
        case 'survey/submit':
            recordFingerPrint(message_data.key, 'submit');

            const on_submit = local_api_call.on_survey_submit;
            if (on_submit && typeof on_submit === 'function') {
                on_submit({
                    data: message_data.data,
                    key: message_data.key
                });
            }

            // close survey after 3 seconds
            local_close_timeout = setTimeout(() => {
                close(survey_key);
            }, 3000);

            break;
        case 'general/height':
            if (current_open_survey && current_open_survey.dom) {
                // check if the message is for the current open survey
                if (message_data.uid !== current_open_survey.uid) return;

                // set iframe height
                const local_survey_dom = current_open_survey.dom;
                const iframe = local_survey_dom.querySelector('iframe');

                var height_old = parseInt(iframe.style.height.replace('px', ''), 10);
                var height_new = message_data.height;

                // do not update the height if it only changes a tiny little bit
                if (Math.abs(height_old - height_new) <= 10) {
                    return;
                }

                iframe.style.height = `${height_new}px`;

                let container;
                if (local_survey_dom.classList.contains(styles.overlay)) {
                    container = local_survey_dom.querySelector(`.${styles.container}`);
                } else {
                    container = local_survey_dom;
                }

                if (container && !container.classList.contains(styles.active)) {
                    // add a small delay so that active class is added after all the height changes
                    setTimeout(() => {
                        container.classList.add(styles.active);
                        updateScrollIndicator(container, current_open_survey.scroll_indicator);
                    }, 100);
                } else if (container) {
                    updateScrollIndicator(container, current_open_survey.scroll_indicator);
                }

                postNativeMessage({ type: 'survey_height', payload: { key: message_data.key, height: message_data.height } });
            }
            break;
        default:
            break;
    }
}

function handlePopState() {
    if (window.location.href === local_initial_url) {
        return;
    }

    if (local_delay_timeout) {
        clearTimeout(local_delay_timeout);
    }

    if (local_close_timeout) {
        clearTimeout(local_close_timeout);
    }

    local_initial_url = window.location.href;

    if (!local_open_survey) {
        return;
    }

    if (local_open_survey.length > 0) {
        return;
    } else {
        trigger();
    }
}

function handleScreenView(e) {
    if (!Config.isMobileSDK()) return;
    if (!e || !e.detail) return;

    // always cancel any pending survey timer on screen change
    if (local_delay_timeout) {
        clearTimeout(local_delay_timeout);
        local_delay_timeout = null;
    }

    // only evaluate surveys on screen enter
    if (e.detail.action !== 'enter') return;

    if (local_configs.length === 0) return;
    if (local_open_survey && local_open_survey.length > 0) return;
    trigger(true);
}
