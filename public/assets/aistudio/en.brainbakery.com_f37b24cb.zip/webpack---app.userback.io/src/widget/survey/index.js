import * as Survey from './survey';

export default Survey;