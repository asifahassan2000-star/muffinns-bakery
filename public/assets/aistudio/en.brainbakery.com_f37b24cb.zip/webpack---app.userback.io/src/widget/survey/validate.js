import {
    DEVICE,
    PAGE_CONDITION,
    SCREEN_CONDITION,
    POSITION,
    SIZE,
    TRIGGER_TYPE
} from './constant';

export function isValidateTriggerType(type) {
    // '' is a valid, deliberate value (in-app trigger disabled) -- only reject when
    // the field is missing/non-string, so a legacy entry without it still falls
    // back to the caller's default trigger_type.
    if (typeof type !== 'string') {
        return false;
    }

    if (!TRIGGER_TYPE.includes(type)) {
        return false;
    }

    return true;
}

export function isValidateFormat(format) {
    if (format === 'paged' || format === 'pageless') {
        return true;
    }

    return false;
}

export function isValidateUiTheme(ui_theme) {
    return ui_theme === '' || ui_theme === 'default' || ui_theme === 'light' || ui_theme === 'dark';
}

export function isValidateTriggerDelay(delay) {
    if (delay === null || delay === undefined) {
        return false;
    }

    if (typeof delay !== 'number') {
        return false;
    }

    if (delay < 0) {
        return false;
    }

    return true;
}

export function isValidateTriggerAction(action) {
    // TODO: Phase 2
    // scroll_half_down, leave_page
    return true;
}

export function isValidateCondition(condition, type) {
    const json_config = condition;

    if (typeof json_config === 'object') {
        // Check whether config is empty
        if (Object.keys(json_config).length === 0) return true;

        const valid_config = validateConditionGroup(json_config, type);

        if (valid_config) return true;
    }

    return false;
}

export function isValidateSurveySize(size) {
    if (!size) {
        return false;
    }

    if (!SIZE.includes(size)) {
        return false;
    }

    return true;
}

export function isValidateFrequency(frequency) {
    if (typeof frequency !== 'string') {
        return false;
    }

    // only format like '', 'always', 'once', 'once_<days>', 'oncesubmit', 'oncesubmit_<days>'
    if (frequency !== '' && frequency !== 'always' && !frequency.match(/^(once|oncesubmit|close)(_[0-9]+)?$/)) {
        return false;
    }

    return true;
}

export function isValidatePosition(position) {
    if (!position) {
        return false;
    }

    if (!POSITION.includes(position)) {
        return false;
    }

    return true;
}

export function isValidateDevice(device) {
    if (!device) {
        return false;
    }

    if (typeof device !== 'string') {
        return false;
    }

    const devices = device.split(',');

    // Loop through each device and validate its value
    for (const device of devices) {
        if (!DEVICE.includes(device)) {
            return false;
        }
    }

    return true;
}

export function isValidateUserSegment(segment) {
    if (segment === '') {
        return true;
    }

    // check if segment is an array
    if (!Array.isArray(segment)) {
        return false;
    }

    // check if segement item is object
    if (!segment.every(item => typeof item === 'object')) {
        return false;
    }

    return true;
}

export function isValidateBackgroundColour(colour) {
    if (!colour) {
        return false;
    }

    if (typeof colour !== 'string') {
        return false;
    }

    const [bg_colour, bg_opacity] = colour.split(',');
    if (!bg_colour || !bg_opacity) {
        return false;
    }

    if (bg_opacity < 0 || bg_opacity > 100) {
        return false;
    }

    return true;
}

function validateConditionGroup(group, type) {
    const validOperators = ['and', 'or'];

    if (!group || !group.operator || !group.conditions || !Array.isArray(group.conditions)) {
        return false;
    }
    if (!validOperators.includes(group.operator.toLowerCase())) {
        return false;
    }

    return group.conditions.every((condition) => {
        if (type === 'page') {
            return validateCondition(condition, 'page');
        } else if (type === 'event') {
            return validateCondition(condition, 'event');
        } else {
            return false; // Invalid type
        }
    });
}

function validateCondition(condition, type) {
    if (type === 'event') {
        // For event conditions, we only validate the type and value
        return (
            condition &&
            Object.hasOwn(condition, 'event_name') &&
            Object.hasOwn(condition, 'meta_key') &&
            Object.hasOwn(condition, 'operator') &&
            Object.hasOwn(condition, 'value')
        );
    } else {
        return (
            condition &&
            condition.type &&
            condition.value &&
            PAGE_CONDITION.includes(condition.type.toLowerCase())
        );
    }
}

export function isValidateScreenCondition(condition) {
    if (typeof condition !== 'object' || condition === null) {
        return false;
    }

    if (Object.keys(condition).length === 0) return true;

    if (!condition.operator || !Array.isArray(condition.conditions)) {
        return false;
    }

    return condition.conditions.every((c) =>
        c && c.type && typeof c.value === 'string' && SCREEN_CONDITION.includes(c.type.toLowerCase())
    );
}
