// TODO: those contants should be shared with other modules
export const DEVICE = ['desktop', 'mobile', 'tablet'];
export const PAGE_CONDITION = ['exact_url_match', 'url_start', 'url_end', 'url_contains', 'url_not', 'url_contains_not', 'url_regex'];
export const SCREEN_CONDITION = ['screen_name_exact', 'screen_name_contains', 'screen_name_contains_not', 'screen_name_start', 'screen_name_end', 'screen_name_not', 'screen_name_regex'];
export const POSITION = ['top_left', 'top', 'top_right', 'bottom_left', 'bottom', 'bottom_right', 'center', 'left', 'right'];
export const SIZE = ['smaller', 'smaller_widget', 'small', 'small_wide', 'medium', 'medium_wide', 'large', 'large_wide', 'larger', 'larger_wide', 'largest'];
// '' means no in-app trigger is configured (reachable via the follow-up email link
// instead) -- distinct from a missing/invalid value, which falls back to the
// default trigger_type instead of disabling the in-app trigger.
export const TRIGGER_TYPE = ['time', 'api', 'element', 'rage', 'event', ''];